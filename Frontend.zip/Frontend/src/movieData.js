
export const featuredMovie = {
  publisher: 'A Disney Original Film',
  title: 'RAYA AND THE LAST DRAGON',
  imageSrc: 'public/img/star/raya-the-last-dragon-star-container.png',
  backgroundGif: '../public/gif/raya.gif',
  backgroundHolder: '../public/img/star/raya-the-last-dragon-background.png',
};
