﻿namespace Project.DTOs.UserDTOs;

public class UserResponseDTO
{
    public string? Firstname { get; set; }
    public string? Lastname { get; set; }
    public string Nickname { get; set; }
    public string Country { get; set; }
    public string Status { get; set; }
}