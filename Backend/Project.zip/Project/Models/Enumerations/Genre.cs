﻿namespace Project.Models.Enumerations;

public enum Genre
{
    Action,
    Romantic,
    SciFi,
    Comedy,
    Drama,
    Thriller,
    Mystery,
    Crime,
    Superhero
}
