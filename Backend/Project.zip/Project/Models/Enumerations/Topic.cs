﻿namespace Project.Models.Enumerations;

public enum Topic
{
    Politics,
    Protest,
    Medical,
    Health,
    Violence,
    Science,
    Environment
}
