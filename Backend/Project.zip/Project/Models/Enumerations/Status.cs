﻿namespace Project.Models.Enumerations;

public enum Status
{
    Student,
    Normal,
    Elder
}
